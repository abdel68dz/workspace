<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Choisir son broker c'est ma&#238;triser son investissement.
Retrouvez nos meilleurs comparatifs, des experts vous offrent leurs avis tout les
jours !" />
    <meta name="keywords" content="Comparatif meilleur broker, Meilleur broker, Liste meilleurs brokers, trading brokers 2020">
    <meta name="author" content="Impartial-verdict">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="shortcut icon" type="image/png" href="impartial.ico"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="canonical" href="https://www.impartial-verdict.com/" />
  
    <title>Liste meilleurs brokers - IMPARTIAL VERDICT</title>
</head>
<body>
  
      
    <div id="wrapper">
        
          <header>

            <div class="toolsBar">
            <div class="men">
                <button class="react">
                    <div></div>
                    <div></div>
                    <div></div>
                  </button>
                     <h5>Menu</h5>
               </div>

                  <h3>Espace Client</h3>
                  <span>

                    <h6>Bonjour, Jean !</h6>
                    <img class="logo" src="img/impartial.png" width="25" alt="">

                  </span>
                  
                  
            </div>

    <div class="menuFix">
      
        <img class="close" src="img/cross.png" width="27" alt="">
        <nav>
        <div class="link">
            <a class="elementi" href="#Compte">Mon compte</a>
            <a class="elementi" href="#Infos">Mes informations</a>
            <a class="elementi" href="#CP">Copy-Trading</a class="elementi">
            <a class="elementi" href="#CPv">Copy-Trading VIP</a class="elementi">
            <a class="elementi" href="#GOvip">Devenir VIP</a class="elementi">
        </div>

        </nav>

    </div>
          
          

         </header>

         <div id="EspaceClient">


        <div class="contain">
            <h2>Mon espace personnel</h2>

        <section id="espacePerso">

            <label for = "email">E-mail :</label>
            <input class="form-control email" id="email" type="text" placeholder="helloworld@gmail.com" readonly>
        <div class="align">
            <div class="info"> 
                <label for = "nom">Nom :</label>
                <input class="form-control name" id="nom" type="text" placeholder="Jean" readonly>

            </div>
            <div class="info"> 
                <label for = "prenom">Prénom :</label>
                <input class="form-control name" id="prénom" type="text" placeholder="Valjean" readonly>
            </div>
        </div>
        <label for = "naissance">Date de naissance :</label>
        <input class="form-control email" id="naissance" type="text" placeholder="15/08/1997" readonly>
          


        </section>
    </div>

            </div>

    </div>



    <footer>
      
    </footer>

    <script src="js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/4aab36eeb4.js" crossorigin="anonymous"></script>

</body>
</html>				