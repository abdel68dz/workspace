let buttonMenu = document.querySelector(".react")
let menuFixed = document.querySelector(".menuFix")
let closeMenu = document.querySelector(".close")
let item = document.querySelectorAll(".elementi")



buttonMenu.addEventListener('click', function(){
    menuFixed.classList.add("menuFix1")
    buttonMenu.style.display = "none"
    document.querySelector(".toolsBar").style.width= "82%"
    document.querySelector("h3").style.marginLeft= "1em"
    document.querySelector(".toolsBar").style.marginLeft= "auto"
    document.querySelector(".toolsBar").style.transitionDuration= "1.5s"
    
})
closeMenu.addEventListener('click', function(){
    menuFixed.classList.remove("menuFix1")
    buttonMenu.style.display = "block"
    document.querySelector("h3").style.marginLeft= "0"
    document.querySelector(".toolsBar").style.width= "100%"
    document.querySelector(".toolsBar").style.marginLeft= "auto"
    document.querySelector(".toolsBar").style.transitionDuration= "1.429s"
})

for (let i=0 ; i < item.length ; i++) {
    console.log(item[i])
    item[i].addEventListener("mouseenter", function() {
       
        item[i].style.marginLeft = "3em"
        item[i].style.transitionDuration = "1s"
        
        })
        item[i].addEventListener("mouseleave", function() {
       
            item[i].style.marginLeft = "0.5em"
            item[i].style.transitionDuration = "1s"
            
            })

}
