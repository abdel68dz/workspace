// --------------- Gestionnaire effect Opacity and other
let etoro = document.querySelector("#etoroavis")
let libertex = document.querySelector("#libertexavis")
let bdswiss = document.querySelector("#bdswissavis")
let iqoption = document.querySelector("#iqoptionavis")
let avatrade = document.querySelector("#avatradeavis")
let maxO = 1
let a = window.pageYOffset
let c = document.body.scrollTop
let b = document.querySelector("nav")

console.log(a)
if(window.matchMedia("(max-width: 991px)").matches){
    document.querySelector("#banner").style.display = "none"
}

window.onscroll = function() {

    console.log('top: '  + (window.pageYOffset || document.body.scrollTop) )

if (window.pageYOffset > 0 || document.body.scrollTop > 0) {

        
    for(i=0 ; i < maxO; i++) {
        
        setTimeout(function() {etoro.style.opacity = i
            etoro.style.transitionDuration = "1.5s";}, 10);
    }
    
        

   }

else {
etoro.style.opacity = "0.3"
}


if (window.pageYOffset > 240 || document.body.scrollTop > 240) {

   if (window.matchMedia("(min-width: 991px)").matches) {
             b.classList.add("st")
             
              } 
   else if (window.matchMedia("(max-width: 991px)").matches) {
             b.classList.add("st")
             document.querySelector("#banner").style.display = "none"
              } 
     

}

else {
   if (window.matchMedia("(min-width: 991px)").matches) {
         b.classList.remove("st")
       
              } 
      else if (window.matchMedia("(max-width: 991px)").matches) {
             b.classList.add("st1")
           
              } 

}

if (window.matchMedia("(max-width: 991px)").matches) {
if (window.pageYOffset > 0  || document.body.scrollTop > 0) {
    b.style.opacity = "0.9"
}
else {
    b.style.opacity = "1"
}

}

if (window.pageYOffset > 1069 || document.body.scrollTop > 1069) {

        
    for(i=0 ; i < maxO; i++) {
        
        setTimeout(function() {libertex.style.opacity = i
            libertex.style.transitionDuration = "1.5s";}, 10);
    }
    
        

   }

else {
libertex.style.opacity = "0.3"
}

if (window.pageYOffset > 2069 || document.body.scrollTop > 2069) {

        
    for(i=0 ; i < maxO; i++) {
        
        setTimeout(function() {bdswiss.style.opacity = i
            bdswiss.style.transitionDuration = "1.5s";}, 10);
    }
    
        

   }

else {
bdswiss.style.opacity = "0.3"
}

if (window.pageYOffset > 3069 || document.body.scrollTop > 3069) {

        
    for(i=0 ; i < maxO; i++) {
        
        setTimeout(function() {iqoption.style.opacity = i
            iqoption.style.transitionDuration = "1.5s";}, 10);
    }
    
        

   }

else {
iqoption.style.opacity = "0.3"
}

if (window.pageYOffset > 4069 || document.body.scrollTop > 4069) {

        
    for(i=0 ; i < maxO; i++) {
        
        setTimeout(function() {avatrade.style.opacity = i
            avatrade.style.transitionDuration = "1.5s";}, 10);
    }
    
        

   }

else {
etoro.style.opacity = "0.3"
}

}

//------------------------- Menu <a> display hover

let navItem = document.querySelector(".visible")
let navLink = document.querySelector(".visible1")
let dropdownMenu = document.querySelector(".visible2")
let navItem1 = document.querySelector(".visiblee")
let navLink2 = document.querySelector(".visiblee1")
let dropdownMenu3 = document.querySelector(".visiblee2")

console.log(navItem)

if (window.matchMedia("(min-width: 992px)").matches) {
navItem.addEventListener("mouseenter", function() {
navItem.classList.add("show")
navLink.attributes[6].value = 'true'
dropdownMenu.classList.add("show")

})

navItem.addEventListener("mouseleave", function () {

        navItem.classList.remove("show")
    navLink.attributes[6].value = 'false'
    dropdownMenu.classList.remove("show")

    
    
    })


   
    console.log(navItem)
    navItem1.addEventListener("mouseenter", function() {
    navItem1.classList.add("show")
    navLink2.attributes[6].value = 'true'
    dropdownMenu3.classList.add("show")
    
    })
    navItem1.addEventListener("mouseleave", function () {
    
            navItem1.classList.remove("show")
        navLink2.attributes[6].value = 'false'
        dropdownMenu3.classList.remove("show")

        
        
        })
    }
   
    let navi = document.querySelector(".es")
    let navi1 = document.querySelector(".es1")
    let navi2 = document.querySelector(".es2")
    let navii = document.querySelector(".ess")
    let navii1 = document.querySelector(".ess1")
    let navii2 = document.querySelector(".ess2")

    if  (window.matchMedia("(max-width: 992px)").matches) {
   console.log("navi")

        navi.classList.remove("visible")
        navi1.classList.remove("visible1")
        navi2.classList.remove("visible2")

        navii.classList.remove("visiblee")
        navii1.classList.remove("visiblee1")
        navii2.classList.remove("visiblee2")

    }