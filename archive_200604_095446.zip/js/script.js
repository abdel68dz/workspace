let a = window.pageYOffset
let c = document.body.scrollTop
let b = document.querySelector("nav")
//------------------------------------------- Menu sticky and media queries

if(window.matchMedia("(max-width: 991px)").matches){
    document.querySelector("#banner").style.display = "none"
}


window.onscroll=function(){
    console.log( 
        'top: '  + (window.pageYOffset || document.body.scrollTop) )
if (window.pageYOffset > 230 || document.body.scrollTop > 230) {
   
       if (window.matchMedia("(min-width: 991px)").matches) {
                 b.classList.add("st")
                 
                  } 
       else if (window.matchMedia("(max-width: 991px)").matches) {
                 b.classList.add("st")
                 document.querySelector("#banner").style.display = "none"
                  } 
         

}

else {
       if (window.matchMedia("(min-width: 991px)").matches) {
             b.classList.remove("st")
           
                  } 
          else if (window.matchMedia("(max-width: 991px)").matches) {
                 b.classList.add("st1")
               
                  } 
   
}

if (window.matchMedia("(max-width: 991px)").matches) {
    if (window.pageYOffset > 0  || document.body.scrollTop > 0) {
        b.style.opacity = "0.9"
    }
    else {
        b.style.opacity = "1"
    }

}

}


//------------------------- Menu <a> display hover

let navItem = document.querySelector(".visible")
let navLink = document.querySelector(".visible1")
let dropdownMenu = document.querySelector(".visible2")
let navItem1 = document.querySelector(".visiblee")
let navLink2 = document.querySelector(".visiblee1")
let dropdownMenu3 = document.querySelector(".visiblee2")

console.log(navItem)

if (window.matchMedia("(min-width: 992px)").matches) {

 

navItem.addEventListener("mouseenter", function() {
navItem.classList.add("show")
navLink.attributes[6].value = 'true'
dropdownMenu.classList.add("show")

})



navItem.addEventListener("mouseleave", function () {

        navItem.classList.remove("show")
    navLink.attributes[6].value = 'false'
    dropdownMenu.classList.remove("show")

    
    
    })


   
    console.log(navItem)
    navItem1.addEventListener("mouseenter", function() {
    navItem1.classList.add("show")
    navLink2.attributes[6].value = 'true'
    dropdownMenu3.classList.add("show")
    
    })
    navItem1.addEventListener("mouseleave", function () {
    
            navItem1.classList.remove("show")
        navLink2.attributes[6].value = 'false'
        dropdownMenu3.classList.remove("show")

        
        
        })
    }
   
    let navi = document.querySelector(".es")
    let navi1 = document.querySelector(".es1")
    let navi2 = document.querySelector(".es2")
    let navii = document.querySelector(".ess")
    let navii1 = document.querySelector(".ess1")
    let navii2 = document.querySelector(".ess2")

    if  (window.matchMedia("(max-width: 992px)").matches) {
   console.log("navi")

        navi.classList.remove("visible")
        navi1.classList.remove("visible1")
        navi2.classList.remove("visible2")

        navii.classList.remove("visiblee")
        navii1.classList.remove("visiblee1")
        navii2.classList.remove("visiblee2")

    }
    
     document.querySelector("#btn4").addEventListener('click', function() {
            console.log("HELLO")
    if (btnn.disabled = true) {
          document.querySelector(".validation").style.border = "solid 2px red";
                    }
})
