<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Connectez-vous pour accèder à la session Copy-trading..." />
    <meta name="keywords" content="Comparatif meilleur broker, Meilleur broker, Liste meilleurs brokers, trading brokers 2020">
    <meta name="author" content="Impartial-verdict">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/inscri.css" />
    <link rel="shortcut icon" type="image/png" href="impartial.ico"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="canonical" href="https://www.impartial-verdict.com/" />
   
    <title>Avis meilleur brokers - IMPARTIAL VERCIT</title>
</head>
<body>
  
        <h1 class="nonam">COMPARATIF MEILLEUR BROKER 2020 !</h1>
    <div id="wrapper">

      <header>

        <div id="banner">

          <img src="img/ipv.jpg" alt="icone impartial verdict">
          <a class="navbar-brand naver" href="index.php">
          </a>

      </div>
       
      <?php include("includes/navbar.php"); ?>

   </header>
        <div id="container">

          <h1 class="titreco">Connexion</h1>

          <form>
            <div class="centre">
            <div class="form-group sizing">
              <label for="exampleInputEmail1">Adresse Email</label>
              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
              <small id="emailHelp" class="form-text text-muted">Ne jamais transmettre vos identifiants quelque soit la personne.</small>
            </div>
            <div class="form-group sizing">
              <label for="exampleInputPassword1">Mot de passe</label>
              <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Mot de passe">
            </div>
            <button class="signup" type="submit" class="btn btn-primary">Se connecter</button>
          </div>
          </form>
         


            </div>

    </div>



    <footer>
        <section class="reseau">
            <a class="res" href="https://www.instagram.com/impartialverdict1/"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/220px-Instagram_logo_2016.svg.png" alt="instagram" width="25px"></a>
            <a class="res" href="https://twitter.com/ImpartialVerdi1"><img src="img/twitter.png" alt="twitter" width="25px"></a>
            <a class="res" href="https://www.facebook.com/Impartial-Verdict-107190407512210/"><img src="https://cdn.icon-icons.com/icons2/159/PNG/256/facebook_22567.png" alt="facebook" width="25px"></a>
            <a class="res" href="https://www.youtube.com/channel/UCMWB1JNa2hpZGlHyytVExLA"><img src="https://www.businessinsider.fr/content/uploads/2017/08/you-800x400.png" alt="youtube" width="50px"></a>
          </section>
    </footer>

    <script src="js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/4aab36eeb4.js" crossorigin="anonymous"></script>
</body>
</html>	