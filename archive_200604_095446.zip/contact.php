<?php

session_start();



?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Connectez-vous pour accèder à la session Copy-trading..." />
    <meta name="keywords" content="Comparatif meilleur broker, Meilleur broker, Liste meilleurs brokers, trading brokers 2020">
    <meta name="author" content="Impartial-verdict">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/inscri.css" />
    <link rel="shortcut icon" type="image/png" href="impartial.ico"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="canonical" href="https://www.impartial-verdict.com/" />
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/4aab36eeb4.js" crossorigin="anonymous"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <title>Avis meilleur brokers - IMPARTIAL VERCIT</title>
</head>
<body>
  

    <div id="wrapper">

          <header>
            <div id="banner">

                <img src="img/ipv.jpg" alt="icone impartial verdict">
                <a class="navbar-brand naver" href="index.php">
                </a>

            </div>

            <?php include("includes/navbar.php"); ?>

           </header>

        <div id="container">

          <h1 class="titreco">Contact</h1>

          <?php if(isset($_SESSION["success"])) {echo $_SESSION["success"];} ?>
          <form class="eng" method="POST" action="server/formContact.php">
          <div class="row x2 x3">
                <div class="col x5">
                <label for="prenom">Prénom* :</label>
                  <input name="prenom" type="text" class="form-control" id="prenom" placeholder="Votre Prénom" value='<?php if(isset($_SESSION["prenom"])){echo $_SESSION["prenom"];}?>'>
                </div>
                <div class="col">
                <label for="nom">Nom* :</label>
                  <input name="nom" type="text" class="form-control" id="nom" placeholder="Votre Nom" value='<?php if(isset($_SESSION["nom"])){echo $_SESSION["nom"];}?>' required>
                </div>
              </div>

              <div class="row x2 x3">
                <div class="col x5">
                <label for="email">Adresse E-mail* :</label>
<input name="email" type="text" class="form-control" id="email" placeholder="Votre adresse E-mail" value='<?php if(isset($_SESSION["email"])){echo $_SESSION["email"];}?>'>
<?php if(isset($_SESSION["error_mail"])){echo "<br><small class='red'>" .$_SESSION['error_mail']. "</small>";}?> 
                </div>
                <div class="col">
                <label for="numero">Numéro de téléphone* :</label>
                  <input name="numero" type="tel" class="form-control" id="numero" placeholder="Votre Numéro de téléphone" value='<?php if(isset($_SESSION["numero"])){echo $_SESSION["numero"];}?>' required>
                  <?php if(isset($_SESSION["error_num"])){echo "<br><small class='red'>" .$_SESSION['error_num']. "</small>";}?> 
                </div>
              </div>
              <div class="form-group x2">
                <label for="objet">Objet de votre  demande* :</label>
                <input name="objet" class="form-control" id="objet" placeholder="Sujet de votre message"value='<?php if(isset($_SESSION["objet"])){echo $_SESSION["objet"];}?>'  required>
              </div>

             <div class="form-group x2">
             <label for="message1">Votre Message* :</label>
                <textarea name="message1" class="form-control" placeholder="Votre Message..." id="message1" rows="3" required><?php if(isset($_SESSION["message1"])){echo $_SESSION["message1"];}?></textarea>
              </div>
              <?php if(isset($_SESSION["error_empty"])){echo "<br><big>" .$_SESSION['error_empty']. "</big></br>";}; ?>
              <p>Tous les champs suivi  d'un (*) devront être remplis !</p>
              <button class="button1 signup" type="submit" disabled>Envoyer</button>
            

            </form>

            <div class="g-recaptcha validation" data-callback="recaptcha_callback" data-sitekey="6Lfpc9sUAAAAANLZf4pIvaL-KLKCbdHsIchZYcyw"></div>
            <style>
            .validation{
                margin-left: 11em;
            }
            </style>
            <script type="text/javascript">
    function recaptcha_callback(){
      let btnn = document.querySelector(".button1");
       console.log(btnn);
             if (btnn.disabled = true) {
                     btnn.disabled = false;
                                }
}
    
</script>
         
            <br><br><br>

            </div>

    </div>



    <footer>
        <section class="reseau">
            <a class="res" href="https://www.instagram.com/impartialverdict1/"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/220px-Instagram_logo_2016.svg.png" alt="instagram" width="25px"></a>
            <a class="res" href="https://twitter.com/ImpartialVerdi1"><img src="img/twitter.png" alt="twitter" width="25px"></a>
            <a class="res" href="https://www.facebook.com/Impartial-Verdict-107190407512210/"><img src="https://cdn.icon-icons.com/icons2/159/PNG/256/facebook_22567.png" alt="facebook" width="25px"></a>
            <a class="res" href="https://www.youtube.com/channel/UCMWB1JNa2hpZGlHyytVExLA"><img src="https://www.businessinsider.fr/content/uploads/2017/08/you-800x400.png" alt="youtube" width="50px"></a>
          </section>
    </footer>

    <script src="js/script.js"></script>
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    

</body>
</html>		
<?php session_destroy(); ?>	