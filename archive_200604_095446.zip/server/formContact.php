<?php

session_start();



foreach($_POST as $key => $value){
    if(isset($value) && !empty($value)){
        ${$key} = htmlspecialchars($value);
        ${$key} = strip_tags($value);
        $_SESSION[$key] = ${$key};

    }
    else {
    $_SESSION["error_empty"] = "Remplir les champs vides !";
      
      
    }
    
}

if(isset($_SESSION["error_empty"])){
    header("Location: ../contact.php");
    exit();
}

if(filter_var($email, FILTER_VALIDATE_EMAIL)){
    $_SESSION["email"] = $email;
    echo "L'adresse " .$email. " est une adresse valide <br>";

}else{
    var_dump(filter_var($email, FILTER_VALIDATE_EMAIL)); 
    $_SESSION["error_mail"] = "L'adresse e-mail est invalide !";
    header("Location: ../contact.php");

}
$numero = str_replace(" ","", $numero);
if (!preg_match('/^[0-9]{10}$/', $numero)){
    $_SESSION["error_num"] = "Veuillez renseigner un numéro de téléphone valide !";
    header("Location: ../contact.php");
      exit();
}


$to      = 'contact@impartial-verdict.com';
$subject = 'De : ' . $prenom . ' ' . $nom. ' Objet du message : ' .$objet;
$message = $message1;
$headers = 'From: ' .$email . "\r\n" .
'Reply-To: contact@impartial-verdict.com' . "\r\n" .
'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

if(mail($to, $subject, $message, $headers)){

foreach($_POST as $key => $value){
    ${$key} = "";
    $_SESSION[$key] = ${$key};
}
$_SESSION["success"] = "<h1>Votre message a bien été envoyé !</h1>";
header("Location: ../contact.php");
exit();
}

?>