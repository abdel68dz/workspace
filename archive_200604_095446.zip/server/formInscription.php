<?php

        
    function secu($data) {
        $data = strip_tags($data);
        $data = trim($data);
        $data = stripslashes($data);

        return $data;
    }

$date = date("d-m-Y");
   

    $name = secu($_POST['inputname']);
    $firstname = secu($_POST['inputfirstname']);
    $email1 = secu($_POST['inputemail']);
    $pass = secu($_POST['pass']);
    $adresse = secu($_POST['inputaddress']);
    $adresse2 = secu($_POST['inputaddress2']);
    $ville = secu($_POST['inputcity']);
    $pays = secu($_POST['inputstate']);
    $cp = secu($_POST['inputzip']);




    $hashed_pass = password_hash($pass, PASSWORD_DEFAULT, ['cost' => 14]);


       
 $server = 'localhost';
 $login = 'impar1313849';
 $pass = "xygyzncjrz"; 

 try {

    $connect = new PDO("mysql:host=185.98.131.109;dbname=impar1313849", $login, $pass);
    $connect -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo 'Connexion réussie !';

    $requete = $connect -> prepare("INSERT INTO users(date,nom,prenom,email,pass,adresse1,adresse2,ville,pays,cp)
                VALUES(:date, :nom, :prenom, :email, :pass, :adresse1, :adresse2, :ville, :pays, :cp)");
    $requete -> bindParam(':date', $date);           
    $requete -> bindParam(':nom', $name);
    $requete -> bindParam(':prenom', $firstname);
    $requete -> bindParam(':email', $email1);
    $requete -> bindParam(':pass', $hashed_pass);
    $requete -> bindParam(':adresse1', $adresse);
    $requete -> bindParam(':adresse2', $adresse2);
    $requete -> bindParam(':ville', $ville);
    $requete -> bindParam(':pays', $pays);
    $requete -> bindParam(':cp', $cp);
    $requete -> execute();
    
    echo $name;
   
 }

catch(PDOException $e){
    echo "Echec de la connexion : " .$e->getMessage();
}
        
   ?>

