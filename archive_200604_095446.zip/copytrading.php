<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Obtenez des trades de qualité en permanance et augmentez votre retour sur investissement..."/>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/copy.css" />
    <link rel="shortcut icon" type="image/png" href="impartial.ico"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
    <title>Avis meilleur broker - IMPARTIAL VERDICT</title>
</head>
<body>
  

    <div id="wrapper">

      <header>

        <div id="banner">

          <img src="img/ipv.jpg" alt="icone impartial verdict">
          <a class="navbar-brand naver" href="index.php">
          </a>

      </div>
       
      <?php include("includes/navbar.php"); ?>


   </header>


          <div id="container">
            

            <h1><strong>Maximiser vos gains grâce au Copy-Trading !</strong></h1>


            <p class="gain">Un investissement bien maîtrise, c'est une réussite quasi-garantie sur bien des points ! Et heureusement chez Impartial-Verdict.com plus besoin
              de main d'expert pour gérer votre capital, la seule chose à faire : c'est faire comme nous !<br><br>
              En effet, le Copy-Trading reste un des meilleurs moyens en 2020 pour réaliser des profits à grande ou à petites échelles selon vos capacités
              d'investissement. Dans tous les cas, notre session de Copy-Trading est totalement gratuite et ouverte à tous. Il suffit de s'inscrire
              sur notre site et de se laisser guider.<br><br>
              Une fois inscrit sur notre site, nos traders se chargeront vous donnez les meilleurs trades possible afin de maximiser vos gains. Sachez aussi qu'une 
              session chat en direct avec nos meilleurs traders sera très prochainement disponible, ils vous accorderont le plus de temps possible afin de répondre
              à vos questions ou même vous conseiller sur certains points concernant le trading.
                
            </p>

              <h2>Bientôt disponible !</h2>
          



                
    </div>
</div>
    <footer>
        <section class="reseau">
            <a class="res" href="https://www.instagram.com/impartialverdict1/"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/220px-Instagram_logo_2016.svg.png" alt="instagram" width="25px"></a>
            <a class="res" href="https://twitter.com/ImpartialVerdi1"><img src="img/twitter.png" alt="twitter" width="25px"></a>
            <a class="res" href="https://www.facebook.com/Impartial-Verdict-107190407512210/"><img src="https://cdn.icon-icons.com/icons2/159/PNG/256/facebook_22567.png" alt="facebook" width="25px"></a>
            <a class="res" href="https://www.youtube.com/channel/UCMWB1JNa2hpZGlHyytVExLA"><img src="https://www.businessinsider.fr/content/uploads/2017/08/you-800x400.png" alt="youtube" width="50px"></a>
          </section>
    </footer>
    <script src="js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/4aab36eeb4.js" crossorigin="anonymous"></script>
    
</body>
</html>		