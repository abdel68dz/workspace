<?php
header("Status: 301 Moved Permanently", false, 301);
header("Location: http://partners.etoro.com/B10212_A85872_TClick_Simpartialverdict.aspx");
exit();
?>