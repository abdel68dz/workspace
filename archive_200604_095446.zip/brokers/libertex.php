<?php
header("Status: 301 Moved Permanently", false, 301);
header("Location: https://record.fxclubaffiliates.com/_Cf2Oitw0NjeF1ad6HiJuLmNd7ZgqdRLk/1/");
exit();
?>