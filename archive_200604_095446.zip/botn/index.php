<?php
$maxValue = 1;
for ($i=0; $i<$maxValue ; $i++){
sleep(1);

 
    $timeout=29; //by default, wait no longer than 5 secs for a response
    
    //init and set cURL options
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

    //if you're using custom flags (like flags=m), change the URL below
    curl_setopt($ch, CURLOPT_URL, "https://igmaxe.com");
    $response=curl_exec($ch);
    
    curl_close($ch);
    


    if (strpos($response, 'dsfdggfh') !== false) {
        echo "match !";
}
else {
    echo "not match !";
}

}



?>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Choisir son broker c'est ma&#238;triser son investissement.
Retrouvez nos meilleurs comparatifs, des experts vous offrent leurs avis tout les
jours !" />
    <meta name="keywords" content="Comparatif meilleur broker, Meilleur broker, Liste meilleurs brokers, trading brokers 2020">
    <meta name="author" content="Impartial-verdict">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="shortcut icon" type="image/png" href="impartial.ico"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="canonical" href="https://www.impartial-verdict.com/" />
  
    <title>Liste meilleurs brokers - IMPARTIAL VERDICT</title>
</head>
</html>